#include <stdio.h>

int main() {
    int i, j;

    // Outer loop: Table number 1 to 10
    for (i = 1; i <= 10; i++) {
        printf("\nMultiplication Table for %d\n", i);
        printf("------------------------\n");

        // Inner loop: 1 to 10
        for (j = 1; j <= 10; j++) {
            printf("%d x %d = %d\n", i, j, i * j);
        }
    }

    return 0;
}
